from django.contrib import admin
from . import models


admin.site.register(models.Header)
admin.site.register(models.AboutMe)
admin.site.register(models.Technology)
admin.site.register(models.Tools)
admin.site.register(models.OtherSkills)
admin.site.register(models.Project)
